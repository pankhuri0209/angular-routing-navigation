import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompaniesinfoComponent } from './companiesinfo.component';

describe('CompaniesinfoComponent', () => {
  let component: CompaniesinfoComponent;
  let fixture: ComponentFixture<CompaniesinfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompaniesinfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompaniesinfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
