import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { CompaniesService } from '../companies.service';
import { Companies } from '../companies';
@Component({
  selector: 'app-companiesinfo',
  templateUrl: './companiesinfo.component.html',
  styleUrls: ['./companiesinfo.component.css'],
})
export class CompaniesinfoComponent implements OnInit {
  company: Companies;
  constructor(
    private route: ActivatedRoute,
    private companyService: CompaniesService
  ) {}

  ngOnInit(): void {
    this.route.params
      .pipe(
        switchMap((params: Params) =>
          this.companyService.getCompany(+params['id'])
        )
      )
      .subscribe((company: Companies) => {
        this.company = company;
      });
  }
}
