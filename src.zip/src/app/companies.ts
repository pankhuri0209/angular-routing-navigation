export class Companies {
  id: number;
  name: String;
  sector: String;
}
