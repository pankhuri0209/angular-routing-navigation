import { Companies } from './companies';

describe('Companies', () => {
  it('should create an instance', () => {
    expect(new Companies()).toBeTruthy();
  });
});
