import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CompaniesinfoComponent } from './companiesinfo/companiesinfo.component';
import { CompaniesComponent } from './companies/companies.component';

const routes: Routes = [
  { path: 'information/:id', component: CompaniesinfoComponent },
  { path: 'companies', component: CompaniesComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
