import { Companies } from './companies';

export const Companiesinfo: Companies[] = [
  { id: 1, name: 'CRAC Infosystems', sector: 'Computer Hardware' },
  { id: 2, name: '4c Plus', sector: 'Softwares in Media' },
  { id: 3, name: 'TCS', sector: 'Consultancy Service' },
];
