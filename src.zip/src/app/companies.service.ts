import { Injectable } from '@angular/core';
import { Companies } from './companies';
import { Companiesinfo } from './companiesinfo';

@Injectable({
  providedIn: 'root',
})
export class CompaniesService {
  getCompany(id: number): Promise<Companies> {
    return this.getCompanies().then((Companies) =>
      Companies.find((Companies) => Companies.id === id)
    );
  }

  getCompanies(): Promise<Companies[]> {
    return Promise.resolve(Companiesinfo);
  }

  constructor() {}
}
