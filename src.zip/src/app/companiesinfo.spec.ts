import { Companiesinfo } from './companiesinfo';

describe('Companiesinfo', () => {
  it('should create an instance', () => {
    expect(new Companiesinfo()).toBeTruthy();
  });
});
