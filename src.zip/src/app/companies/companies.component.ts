import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { CompaniesService } from '../companies.service';
import { Companies } from '../companies';
@Component({
  selector: 'app-companies',
  templateUrl: './companies.component.html',
  styleUrls: ['./companies.component.css'],
})
export class CompaniesComponent implements OnInit {
  companies: Companies[];
  selectedCompany: Companies;
  constructor(
    private router: Router,
    private companyService: CompaniesService
  ) {}

  ngOnInit(): void {
    this.companyService
      .getCompanies()
      .then((companies) => (this.companies = companies));
  }
  showInfo(company: Companies): void {
    this.selectedCompany = company;
    this.router.navigate(['/information', this.selectedCompany.id]);
  }
}
